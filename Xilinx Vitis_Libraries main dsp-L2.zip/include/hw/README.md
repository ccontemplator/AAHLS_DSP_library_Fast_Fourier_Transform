The folder contains headers of prototypes of FFT kernels.

The `vitis_fft` and `vitis_2dfft` contain building blocks for 1D-FFT and 2D-FFT with single precision floating-point and fixed-point data type kernels.

## Level 2: Vitis Benchmarks for FFT Kernels

To get the benchmarks, please kindly refer to the 4 corresponding cases in `L2/tests/hw` folder.

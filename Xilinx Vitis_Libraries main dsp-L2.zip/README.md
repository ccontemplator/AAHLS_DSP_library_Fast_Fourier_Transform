## Level 2: Predefined Vitis Kernels and AIE Graphs

The Level 2 of Vitis DSP Library is presented as OpenCL kernels and AIE graphs.


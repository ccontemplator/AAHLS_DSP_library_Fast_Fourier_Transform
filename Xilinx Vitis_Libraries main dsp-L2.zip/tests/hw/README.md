## Level 2: Vitis Tests for FFT Kernels

This folder contains basic test for each of FFT kernels. They are meant to discover simple regression errors as well as give the 1PU only benchmark performance.

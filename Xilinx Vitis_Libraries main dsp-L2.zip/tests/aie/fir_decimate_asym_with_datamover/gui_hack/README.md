The file "aie_control_xrt.cpp" is taken from AIE compiler work directory (Work/ps/c_rst/aie_control_xrt.cpp) and dynamically generated from graph input. 
It is statically included in library to work-around 21.2 GUI limitation.


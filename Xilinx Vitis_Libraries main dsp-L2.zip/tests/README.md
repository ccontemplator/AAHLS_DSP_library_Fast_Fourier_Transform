## Level 2: Vitis Tests for DSP OpenCL Kernels and AIE Graphs

This folder contains basic test for each of DSP kernels/graphs. They are meant to discover simple regression errors.
